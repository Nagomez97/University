#!/bin/bash

./ejercicio3.sh
./tiempos.sh